# [Terraform Functions](https://developer.hashicorp.com/terraform/language/functions)

  - [Numeric Functions](https://developer.hashicorp.com/terraform/language/functions)
  - [String Functions](https://developer.hashicorp.com/terraform/language/functions)
  - [Collection Function](https://developer.hashicorp.com/terraform/language/functions)
  - [Date & Time Functions](https://developer.hashicorp.com/terraform/language/functions)
  - [Encoding Functions](https://developer.hashicorp.com/terraform/language/functions)
